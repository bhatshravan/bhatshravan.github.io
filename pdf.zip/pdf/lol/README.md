# PDF417-js

PDF417 - 2D barcode generator in Javascript

From input code (any text) creates PDF417 barcode with option to draw it on canvas.

This is direct port of TCPDF PHP library from:
http://www.tcpdf.org/
or 
http://sourceforge.net/projects/tcpdf/files/

Version used for porting is tcpdf_6_2_11 or more specific PDF417 class version 1.0.005.

Also using helper methods from:
http://bcmath-js.sourceforge.net/

##Demo
http://bkuzmic.github.io/pdf417-js/

